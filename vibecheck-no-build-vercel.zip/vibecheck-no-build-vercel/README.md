# VibeCheck No-Build Vercel Version

Vercel settings:
- Framework Preset: Other
- Build Command: leave blank
- Output Directory: .
- Install Command: leave blank

Upload these files to the root of your GitHub repo:
- index.html
- manifest.webmanifest
- sw.js
- icon.svg
- README.md
